module.exports = {
    production: false,
    id_developer: 0
}