
import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Matriculas {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  curso: string;

  @Column()
  nombre: string;

  @Column()
  numeroHoras: number;

  @Column()
  numeroCreditos: number;

  @Column('date')
  fecha: string;

  @Column({ default: true })
  activo: boolean;
}
